## flask 留言板（flaskr_messb）

### 项目前期
#### 设计
![Alt text](./1555337176564.png)
#### 组成
![Alt text](./1555337252570.png)

### 项目中期
#### 代码结构
![Alt text](./1555337542079.png)

1. 配置文件
使用python脚本来倒入配置，主要是对于数据库的相关配置。dev_db变量来表示sqlite数据库的URI。要获取项目的根目录，用 app.root_path。定义密钥SECRET_KEY，SQLALCHEMY_TRACK_MODIFICATIONS ，SQLALCHEMY_DATABASE_URI 三个变量

PS： SQLite数据库URI在Linux和Macos系统下，斜线数量是4个；在WIN系统下，是3个。内存型数据库的斜线固定为3个。

![Alt text](./1555421639025.png)

2. 创建程序实例，初始化拓展
1）导入 SQLAlchemy 、Bootstrap 、Moment三个库；
2）将配置文件config.py的参数传入实例中；
3）引入jinja，设置环境变量，来去掉Jinja2语句所占据的空行  详细可参考  http://greyli.com/flask-template-engine-jinja2-syntax-introduction/
4）引入所需要的对象

![Alt text](./1555421610793.png)

3. 数据库建模
主要有四个字段：留言编号id、留言内容body、留言者name和留言时间timestamp
要引入datetime库，实例中的db对象
![Alt text](./1555422125815.png)

4. 创建表单类
主要引入 wtforms库中的StringField,TextAreaField,SubmitField （名称，提交，内容）、flask_wtf中的FlaskForm;

![Alt text](./1555422590490.png)

5. 视图函数
index视图有两个作用：
* 处理GET请求，从数据库中查询所有的消息记录，返回渲染后的主页模版 index.html
* 处理POST请求，表达提交后，将通过验证的数据保存到数据库，并flash( )函数提示，之后再重定向到视图，渲染函数。

该函数要导入之前的app、db、Message、HelloForm

![Alt text](./1555423888465.png)

6. 错误页面
用来处理错误时函数
![Alt text](./1555423998430.png)

7. 编写模版（采用bootstrap 框架）
该项目主要有两个模版  一个是基模版（base.html），用于减少一些相同的html代码多次使用是的重复编写，全部重用该代码即可；另外一个是主页面（index.html）。

![Alt text](./1555824689833.png)
在head标签和body标签内，引入了Bootstrap所需要的CSS和JS文件，以及Bootstrap所依赖的JjQuery和Popper.js。我们还可以了自定义style.css和script.js文件，分别用于定义CSS样式和JavaScript代码。

![Alt text](./1555824822218.png)
在index模版中，使用的是form_field( )宏渲染表单，之后迭代传入messages变量，来渲染消息列表。

当然更好的方法是采用BootFlask-Flask框架，用其中的WTForms表单类的宏来进行渲染，更为快捷和方便，这个之后会专门挑出来进行单独总结。

8. 生成虚拟数据
使用Faker生成虚拟数据
![Alt text](./1555825784916.png)

###调试阶段遇到的典型问题
* 细节方面  注意代码的拼写
eg:
![Alt text](./1555826228945.png)
这个就是在写视图函数时，http上传方式 method关键字应该是methods

* 项目路径以及文件环境的依赖
eg:
![Alt text](./1555826444444.png)
一般这个错误就是要进入到项目所在路径在运行flask，还有就是flask的环境配置，如：
![Alt text](./1555826522794.png)

* 疑难问题（难以归类，耗时很久解决）
![Alt text](./1555827173875.png)
我碰到的这个问题主要是由于，项目整体的文件结构不对，致使flask无法找到对应的文件代码来运行，就是将文件的根，将文件的根目录也命名为项目名称（flaskr_messb），所以遇到这个问题，请到文章最上面好好看一下整个的项目文件结构。

![Alt text](./1555827360916.png)
这个问题，乍眼一看是一个数据库问题，但是有的时候要定位一下，其实是由于index.html代码内，第二行 {% from 'macros.html'  import form_field %} 这句代码，因为我是用form_field( )宏来进行渲染的，但是我并没有写 macros.html 这个文件。
![Alt text](./1555827731400.png)

![Alt text](./1555851311245.png)
在使用Faker库生成虚拟数据的时候出现了问题，这时候我执行了 pip install fake-factory ，之后再运行项目，出现了这个问题。主要的原因是fake-factory所依赖的一个包 factory_boy在安装特定版本的时候下载的内容又问题。

需要使用requirements.txt来制定所要安装python包的版本。
在虚拟环境中 pip freeze >requirements.txt中追加如下内容：
fake-factory==0.7.4
factory-boy==2.7.0
接着使用如下命令，等待安装完成  pip install -r requirements.txt

以上就是我在写留言板时候遇到的几个比较很典型的问题，做了一个记录和汇总，当然不管是这个项目还是以后的项目，还会有很多很多的问题，问题一个一个来，过程中确实有无奈，沮丧的时候，这些都是自己的财富，但前提是做好记录与总结，不然一段时间后，你可能会不认识它了，共勉！

![Alt text](./1555850983537.png)
PS:该项目学习借鉴指导于《Flask Web开发实战》中

2019.04.21  14:26 于杭州







